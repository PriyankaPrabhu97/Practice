package selenium_IDE;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class main_class 
{
	WebDriver dr;
	
	public main_class(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public WebDriver launch_browser(String Browser,String url)
	
	{
	
		if(Browser.contains("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
			dr=new ChromeDriver();
		}
		else if(Browser.contains("firefox"))
				{
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			dr=new FirefoxDriver();
					
				}
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		return dr;
	}
	
	
	public void methods()
	{
		
		dr.findElement(By.xpath("//a[@class='nav-item'][1]")).click();
		dr.findElement(By.xpath("/html/body/div[2]/div[2]/p/a[2]")).click();
		
		//dr.findElement(By.xpath("//div[@class='split-section container dark-background']//div[2]//p[2]/a")).click();
		
		
		//dr.findElement(By.xpath("//li[@title='Grid']//ul//li[4]")).click();
		//dr.findElement(By.xpath("//div[@class='split-section container']//div[2]//a[2]")).click();
		

	}
	

}
