package Flight_booking;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class NewTest_flight {
	WebDriver dr;
	main_class obj;
	String url="https://www.phptravels.net/home";
	
	
	@BeforeClass
	public void BM()
	{
		obj=new main_class(dr);
		dr=obj.launch_browser("chrome", url);
	}
	
  @Test
  public void f()
  {
	  obj.methods();
	  System.out.println("pass");
  }
}
