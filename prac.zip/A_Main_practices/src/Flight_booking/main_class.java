package Flight_booking;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class main_class 
{
	WebDriver dr;
	
	public main_class(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public WebDriver launch_browser(String Browser,String url)
	
	{
	
		if(Browser.contains("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
			dr=new ChromeDriver();
		}
		else if(Browser.contains("firefox"))
				{
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			dr=new FirefoxDriver();
					
				}
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		return dr;
	}
	
	
	public void methods()
	{
		dr.findElement(By.xpath("//li[@class='fr'][1]")).click();
		
		dr.findElement(By.xpath("//div[@class='dropdown-menu dropdown-menu-right show']//div//a[4]")).click();
		
//		try {
//			Thread.sleep(40);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		dr.findElement(By.xpath("//nav[@class='menu-horizontal-02']//ul/li[1]")).click();
		
		try {
			Thread.sleep(70);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		dr.findElement(By.xpath("//div[@id='s2id_location_from']//a")).click();
//		
//		dr.findElement(By.xpath("//div[@id='select2-drop']//input")).sendKeys("Los Angels");
//		
//		dr.findElement(By.xpath("//div[@id='select2-drop']//ul//li[3]")).click();
//		
//		dr.findElement(By.xpath("//div[@id='select2-drop']//input")).click();
//		dr.findElement(By.xpath("//div[@id='select2-drop']")).sendKeys("Dallas");
//		dr.findElement(By.xpath("//div[@id='select2-drop']//ul//li[4]")).click();
	}
	

}
