package Royalcal;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class main_class {
	
WebDriver dr;
	
	public main_class(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public WebDriver launch_browser(String Browser,String url)
	
	{
	
		if(Browser.contains("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
			dr=new ChromeDriver();
		}
		else if(Browser.contains("firefox"))
				{
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			dr=new FirefoxDriver();
					
				}
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		return dr;
	}
	
	
	public String mathod_1()
	{
		boolean b=dr.findElement(By.xpath("//div[@id='textWithUI-262899300']//div[2]/a")).isDisplayed();
		if(b==true)
		{
			System.out.println("pass");
		}
		else
			System.out.println("fail");
		
		dr.findElement(By.xpath("//div[@class='footer__rcl__row__navigation__cat'][4]//label//div[1]")).click();
		
		dr.findElement(By.xpath("//a[@id='rciHeaderMenuItem-2']")).click();
		
		try {
			Thread.sleep(20);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//dr.findElement(By.xpath("//*[@id=\"staticGalleryComponent-1586874402\"]/a/div/figure/div")).click();
		
		dr.findElement(By.xpath("//section[@class=' left short']//div[16]")).click();
		
		
		dr.findElement(By.xpath("//div[@tabindex='0'][3]")).click();
		
		//dr.findElement(By.xpath("//select[@name='deck-dropdown']")).click();
		
		dr.findElement(By.xpath("//select[@name='deck-dropdown']//option[7]")).click();
		
		
		String name=dr.findElement(By.xpath("//section[@class='deckdeck-plan__stateroom__subtype'][5]//h4")).getText();
		
	return name;
		
	}

}
