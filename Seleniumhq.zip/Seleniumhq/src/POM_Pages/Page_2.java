package POM_Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Base_Class.Wait;

public class Page_2 {

	WebDriver dr;
	Wait wt;
	public Page_2(WebDriver dr)
	{
		this.dr = dr;
		wt = new Wait(dr);
	}
	
	//To click on 64 bit Windows IE & download
	public void download_zip()
	{
		By dwn_zip =By.partialLinkText("64 bit Windows IE");
		WebElement wt_dwn_zip=wt.elementToBeClickable(dwn_zip, 20);
		wt_dwn_zip.click();
		
		//dr.findElement(By.partialLinkText("64 bit Windows IE")).click();
		System.out.println("Click for download");
	}
}
