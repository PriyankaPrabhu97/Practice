package POM_Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Base_Class.Wait;

public class Page_1 {
	
	WebDriver dr;
	Wait wt;
	public Page_1(WebDriver dr)
	{
		this.dr = dr;
		wt = new Wait(dr);
	}
	
	//To click on Downloads
	public void downloads()
	{
		By dwn =By.xpath("//a[@class='nav-item'][1]");
		WebElement wt_dwn=wt.elementToBeClickable(dwn, 20);
		wt_dwn.click();
		
		//dr.findElement(By.xpath("//a[@class='nav-item'][1]")).click();
		System.out.println("Clicked on downloads option in 1st page");
	}

}
