package Base_Class;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Screenshot {

	WebDriver dr;
	public void ss()
	{
		int counter=1;
		String path = "ScreenShots\\SS";
		String filename = counter+".png";
		File f1 = ((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
		File f2 = new File(path+filename);
		
		try {
			FileUtils.copyFile(f1, f2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		counter++;
	}
}
